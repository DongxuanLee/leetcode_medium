
def searchRange(nums, target):
    """
    :type nums: List[int]
    :type target: int
    :rtype: List[int]
    """
    index1 = -1
    index2 = -1
    if not nums:
        return [index1,index2]
    left = 0
    right = len(nums)-1
    if target<nums[left] or target>nums[right]:
        return [index1,index2]
    if nums[left]==nums[right]:
        if target==nums[left]:
            return [left,right]
        else:
            return [index1,index2]
    while nums[left]<=nums[right]:
        medium = (left+right)//2
        if target ==nums[medium]:
            index1 =index2= medium
            while index1>0 and nums[index1-1]==target:
                index1 -= 1
            while index2<len(nums)-1 and nums[index2+1]==target:
                index2 += 1
            return [index1, index2]
        # if medium == left:
        #     return [index1,index2]
        if target >nums[medium]:
            left = medium+1
        else:
            right = medium-1
    return [index1,index2]
if __name__ == '__main__':
    nums = [1,4]
    print(searchRange(nums,target=4))

