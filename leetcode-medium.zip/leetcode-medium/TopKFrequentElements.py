
def topKFrequent(nums, k):
    """
    :type nums: List[int]
    :type k: int
    :rtype: List[int]
    """
    import heapq
    if k>len(nums) or len(nums)==0:
        return []

    numset = {}
    maxstack = []
    for i in nums:
        if i not in numset.keys():
            numset[i] = 1
        else:
            numset[i]+=1
    for key,value in numset.items():
        heapq.heappush(maxstack,(value,key))
        if len(maxstack) >k:
            heapq.heappop(maxstack)

    return list(i[1] for i in maxstack)

if __name__ == '__main__':
    nums = [1, 1, 1, 2, 2, 3]
    k = 2

    print(topKFrequent(nums, k))
