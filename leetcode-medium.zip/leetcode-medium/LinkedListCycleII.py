# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution(object):
    def detectCycle(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        listdic = {}
        p = head
        pos = -1
        while p:
            if p not in listdic.keys():
                listdic[p] = 1
                pos += 1
            else:
                break
            p = p.next
        # return p
        if not p:
            return None
        else:
            return p