
def nextPermutation(nums):
    """
    :type nums: List[int]
    :rtype: None Do not return anything, modify nums in-place instead.
    """
    selast = len(nums)-2
    while selast>0 and (nums[selast+1]<=nums[selast]):
        selast -=1

    if(selast>=0):
        j = len(nums) - 1
        while j>=0 and nums[j]<=nums[selast]:
            j-=1
        swap(nums,j,selast)
    reverse(nums,selast+1)
    return nums
def swap(nums,a,b):
    tmp =nums[b]
    nums[b] = nums[a]
    nums[a] = tmp
def reverse(nums,start):
    end = len(nums)-1
    while start<end:
        swap(nums,start,end)
        start+=1
        end-=1
if __name__ == '__main__':
    nums = [3,2,1]
    print(nextPermutation(nums))