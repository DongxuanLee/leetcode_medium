
def maxProduct(nums):
    """
    :type nums: List[int]
    :rtype: int
    """
    if not nums:
        return 0
    if len(nums)==1:
        return nums[0]
    pmin =999
    pmax =-999
    acmax = -999
    for i in nums:
        if i >0:
            pmax = max(i,pmax*i)
            pmin = min(i,pmin*i)
        elif i==0:
            pmax = 0
            pmin = 0
        else:
            _max = max(pmin*i,i)
            pmin = min(pmax*i,i)
            pmax = _max
        acmax = max(pmax,acmax)
    return acmax
if __name__ == '__main__':
    nums = [2,-1,1,1]

    print(maxProduct(nums))