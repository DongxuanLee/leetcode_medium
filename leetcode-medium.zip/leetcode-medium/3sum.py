
def threeSum( nums):
    """
    :type nums: List[int]
    :rtype: List[List[int]]
    """
    solution = []
    nums.sort()
    for i in range(0,len(nums)-2):
        left = i+1
        right = len(nums)-1
        # while (j-i>2) and j>i:
        #     medium = -(nums[i]+nums[j])
        #     if medium in nums[i+1:j]:
        #         solution.append([nums[i],medium,nums[j]])
        while left<right:
            if nums[i]+nums[left]+nums[right]==0:
                solution.append([nums[i], nums[left], nums[right]])
            while (nums[left]==nums[left+1]) and (left+1<right):
                left+=1
            left+=1
            while (nums[right]==nums[right-1])and (left+1<right):
                right-=1
            right -= 1
    return solution
if __name__ == '__main__':
    nums = [0,0,0]
    print(threeSum(nums))