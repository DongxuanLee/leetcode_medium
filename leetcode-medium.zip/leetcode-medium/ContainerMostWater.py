
def maxArea(height):
    """
    :type height: List[int]
    :rtype: int
    """
    maxarea = 0
    indexend = len(height) - 1
    indexstart = 0
    i = height[0]
    j = height[-1]
    while indexend != indexstart:
        if i <= j:
            area = i * (indexend - indexstart)
            maxarea = max(area, maxarea)
            indexstart += 1
            i = height[indexstart]
        else:
            area = j * (indexend - indexstart)
            maxarea = max(area, maxarea)
            indexend -= 1
            j = height[indexend]
    return maxarea
if __name__ == '__main__':
    height = [1,1]
    print(maxArea( height))