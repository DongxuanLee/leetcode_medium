
def search( nums, target):
    """
    :type nums: List[int]
    :type target: int
    :rtype: int
    """
    if not nums:
        return -1
    left = 0
    right = len(nums) - 1
    if target == nums[left]:
        return left
    if target == nums[right]:
        return right
    if target > nums[right] and target < nums[left]:
        return -1
    while left <= right:
        medium = (left + right) // 2
        if nums[medium] == target:
            return medium
        if medium == left:
            return -1
        if nums[medium] < nums[right]:
            if target > nums[medium] and target < nums[right]:
                left = medium
            else:
                right = medium
        else:
            if target > nums[left] and target < nums[medium]:
                right = medium
            else:
                left = medium
    return -1
if __name__ == '__main__':
    nums = [1,3]

    target = 2
    print(search(nums,target))
