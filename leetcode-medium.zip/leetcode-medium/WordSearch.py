
def exist( board, word):
    """
    :type board: List[List[str]]
    :type word: str
    :rtype: bool
    """
    if not board:
        return False
    m = len(board)
    n = len(board[0])

    def dfs(i,j,b,index):
        if index == len(word):
            return True
        if i < 0 or j < 0 or i == m or j == n:
            return False
        if b[i][j] != word[index]:
            return False
        else:
            tmp = b[i][j]
            b[i][j] = '0'
            ans = dfs(i - 1, j, b, index + 1) or dfs(i + 1, j, b, index + 1) or dfs(i, j - 1, b, index + 1) or dfs(i,j + 1,b,index + 1)
            b[i][j] = tmp
        return ans
    for i in range(m):
        for j in range(n):
            if dfs(i,j,board,0):
                return True
            if i==m-1 and j==n-1 and dfs(i,j,board,0)==False:
                return False
if __name__ == '__main__':
    nums = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]]


    word = "ABCB"

    print(exist(nums,word))