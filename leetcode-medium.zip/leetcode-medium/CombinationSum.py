sumset = []
def combinationSum(candidates, target):
    """
    :type candidates: List[int]
    :type target: int
    :rtype: List[List[int]]
    """


    findoneset(sorted(candidates), target,[])
    return sumset

def findoneset(candidates, target,set):
    if target == 0:
        sumset.append(set)

    for i in range(len(candidates)):
        if candidates[i]>target:
            break

        if target  >= 0:
            findoneset(candidates[i:], target - candidates[i],set+[candidates[i]])
    # return

if __name__ == '__main__':
    nums = [2,3,6,7]
    print(combinationSum(nums,7))