# Definition for singly-linked list.
class ListNode(object):
    def __init__(self, x):
        self.val = x
        self.next = None

class Solution(object):
    def removeNthFromEnd(self, head, n):
        """
        :type head: ListNode
        :type n: int
        :rtype: ListNode
        """
        if not head.next and n==1:
            return []
        fast=slow = head
        slow_pre = slow_ne = head
        # slow_ne = slow_ne.next
        count = 0
        while fast:
           count+=1
           fast = fast.next
           if count ==n:
               break
        while fast:
            fast = fast.next
            slow_ne = slow
            slow = slow.next
            slow_pre = slow.next
        if slow == head:
            head = head.next
        else:
            slow_ne.next = slow_pre
        return head
