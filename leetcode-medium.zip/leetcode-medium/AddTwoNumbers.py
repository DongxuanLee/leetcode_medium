# Definition for singly-linked list.
class ListNode(object):
    def __init__(self, x):
        self.val = x
        self.next = None

class Solution(object):
    def addTwoNumbers(self, l1, l2):
        """
        :type l1: ListNode
        :type l2: ListNode
        :rtype: ListNode
        """
        self.l3 = ListNode(0)
        self.addtwonumber(l1,l2,0)
        return self.l3

    def addtwonumber(self,l1,l2,c):
        x = l1.val + l2.val + c
        self.l3 = ListNode(x%10)
        c = x // 10
        if l1.next or l2.next or c!=0:
            if not l1.next:
                l1.next = ListNode(0)
            if not l2.next:
                l2.next = ListNode(0)
            self.l3.next = self.addtwonumber(l1.next,l2.next,c)

