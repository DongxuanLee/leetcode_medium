
def numSquares( n):
    """
    :type n: int
    :rtype: int
    """
    dp = [0] + [float('inf')] * n
    for i in range(1, n + 1):
        dp[i] = min(dp[i - j * j] for j in range(1, int(i ** 0.5) + 1)) + 1
    return dp[n]
#     memo = {}
#     return squtil(n, int(n ** 0.5), memo)
# def squtil(n,sn,memo):
#     min_cnt = 0
#     if (n, sn) in memo:
#         return memo[(n, sn)]
#     for num in range(sn,0,-1):
#         sq = num*num
#         sq_cnt = 0
#         rest = n
#         while rest>=sq:
#             rest = rest -sq
#             sq_cnt +=1
#         cnt = squtil(rest, int(rest ** 0.5), memo) + sq_cnt
#         if cnt<min_cnt or min_cnt == 0:
#             min_cnt = cnt
#     return min_cnt

if __name__ == '__main__':
    k = 12

    print(numSquares(k))
