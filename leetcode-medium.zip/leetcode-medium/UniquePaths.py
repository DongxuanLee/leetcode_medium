
def uniquePaths( m, n):
    """
    :type m: int
    :type n: int
    :rtype: int
    """
    if (m < 2 or n < 2):
        return 1
    if (m == n == 2):
        return 2
    path = [[0 for x in range(n)] for x in range(m)]
    # print(path)
    for i in range(m):
        path[i][0] = 1
    for i in range(n):
        path[0][i] = 1
    # print(path)
    for i in range(1,m):
        for j in range(1,n):
            path[i][j] = path[i-1][j]+path[i][j-1]
    # result = recur(m-1,n-1,path)
    # print(path[m-1][n-1])
    return path[m-1][n-1]

def recur(m,n,path):
    if m>0 and n>0:
        path[m][n] = recur(m-1,n,path)+recur(m,n-1,path)
    return path[m][n]
if __name__ == '__main__':
    nums = [3,2]

    print(uniquePaths(23,12))
