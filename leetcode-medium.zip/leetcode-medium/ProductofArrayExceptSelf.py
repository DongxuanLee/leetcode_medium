
def productExceptSelf( nums):
    """
    :type nums: List[int]
    :rtype: List[int]
    """
    length = len(nums)
    L, R, answer = [0] * length, [0] * length, [0] * length
    L[0] = 1
    for i in range(1, length):
        L[i] = nums[i - 1] * L[i - 1]
    print(L)
    R[length - 1] = 1
    for j in range(length-1,0,-1):
    # for i in reversed(range(length - 1)):
        R[j-1] = nums[j]*R[j]
        # R[j] = nums[j + 1] * R[j + 1]
    print(R)
    for i in range(length):
        answer[i] = L[i] * R[i]
    print(answer)
    return answer
if __name__ == '__main__':
    nums = [4,5,2,1,8]

    productExceptSelf(nums)
