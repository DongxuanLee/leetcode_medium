
def lengthOfLongestSubstring(s):
    """
    :type s: str
    :rtype: int
    """
    if not s:
        return 0
    sset = {}
    currstart = 0
    count = 0
    for i in range(len(s)):
        if s[i] in sset.keys() and currstart<=sset[s[i]]:
            count = max(i - currstart, count)
            currstart = sset[s[i]] + 1
        sset[s[i]] = i

    return max(len(s)-currstart,count)
if __name__ == '__main__':
    nums = "abba"

    print(lengthOfLongestSubstring(nums))
