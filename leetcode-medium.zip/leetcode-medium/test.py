test= [[1,0],[2,3],[4,5]]
print(test[-1][1])
print(25/10)
print(s)