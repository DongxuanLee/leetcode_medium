
def subsets(nums):
    """
    :type nums: List[int]
    :rtype: List[List[int]]
    """
    if not nums:
        return [[]]
    ans = []
    sub = subsets(nums[1:])
    ans.extend(sub)
    ans.extend([[nums[0]] + item for item in sub])
    return ans
# def findsub(nums):

if __name__ == '__main__':
    nums = [1,2,3]

    print(subsets(nums))

