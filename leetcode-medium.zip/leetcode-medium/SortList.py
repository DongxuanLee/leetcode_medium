# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, x):
#         self.val = x
#         self.next = None

class Solution(object):
    def sortList(self, head):
        """
        :type head: ListNode
        :rtype: ListNode
        """
        if not head:
            return None
        liststack1 = []
        liststack2 = []
        liststack1.append(head)
        p = head.next
        while p:
            if p.val<=liststack1[-1].val:
                liststack1.append(p)
            else:
                while p.val>liststack1[-1].val:
                    q = liststack1.pop()
                    liststack2.append(q)
                liststack1.append(p)
                while liststack2:
                    q = liststack2.pop()
                    liststack1.append(q)
        for i in range(len(liststack1)-1,-1,-1):
            if liststack1[i-1]:
                liststack1[i].next = liststack1[i-1]
            else:
                break
        head = liststack1[-1]
        return head
