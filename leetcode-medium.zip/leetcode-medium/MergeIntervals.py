
def merge( intervals):
    """
    :type intervals: List[List[int]]
    :rtype: List[List[int]]
    """
    if not intervals:
        return
    s= intervals[0][0]
    t = intervals[0][1]
    ans =[]
    for i in range(1,len(intervals)):
        # for j in range(len(intervals[i])):
        if t<intervals[i][0] and s<intervals[i][0]:
            ans.append([s,t])
            s =intervals[i][0]
            t = intervals[i][1]
        elif t>=intervals[i][0] and s<intervals[i][0]:
            t = max(t,intervals[i][0],intervals[i][1])
        elif t>=intervals[i][1] and s>=intervals[i][0]:
            if s<=intervals[i][1]:
                s = min(s,intervals[i][0],intervals[i][1])
            else:
                ans.append(intervals[i])
        elif t<intervals[i][1] and s>=intervals[i][0]:
            t = max(t, intervals[i][0], intervals[i][1])
            s = min(s, intervals[i][0], intervals[i][1])
    ans.append([s,t])
    minans =ans[0][0]
    currans = ans[0][1]
    flag=0
    for i in range(1,len(ans)):
        if ans[i][0]<=currans  or (ans[i][1]==currans and ans[i][0]==minans):
            flag = 1
            break
        minans = ans[i][0]
        currans = ans[i][1]

        # for j in range(len(ans[i])):
        #     if ans[i][j]<minans:
        #         flag =1
        #         break
        #     currans = ans[i][j]
        # if flag==1:
        #     break
    if flag==1:
        return merge(ans)
    return ans

if __name__ == '__main__':
    nums = [[5,7],[5,5],[1,1],[0,0],[3,3],[4,5],[1,1],[3,4]]

    print(merge(nums))
