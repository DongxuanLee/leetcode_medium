# 先进行x或y轴交换，再进行主对角线交换
def rotate( matrix):
    """
    :type matrix: List[List[int]]
    :rtype: None Do not return anything, modify matrix in-place instead.
    """
    if not matrix:
        return
    N = len(matrix)
    cp = []
    for  i in matrix:
        cp.append(i)
    for  r in range(N):
        for i in range(N):
            # matrix[r][r + i], matrix[r + i][N - r], matrix[N - r][N - r - i], matrix[N - r - i][r] = \
            #     matrix[N - r - i][r], matrix[r][r + i], matrix[r + i][N - r], matrix[N - r][N - r - i]
            matrix[i][N-1-r] = cp[r][i]
    return matrix
if __name__ == '__main__':
    nums = [[1,2,3],[4,5,6],[7,8,9]]
    print(rotate(nums))
