
def dailyTemperatures( T):
    """
    :type T: List[int]
    :rtype: List[int]
    """
    if not T:
        return [0]
    stack = []
    ans = []
    for i in range(len(T)-1,-1,-1):
        if len(stack) > 0:
            while len(stack)>0 and stack[-1][1]<=T[i]:
                stack.pop(-1)
            if len(stack) == 0:
                stack.append([i, T[i]])
                ans.insert(0,0)
            else:

                ans.insert(0,stack[-1][0]-i)
                stack.append([i, T[i]])
        else:
            stack.append([i, T[i]])
            ans.insert(0, 0)
    return ans
if __name__ == '__main__':
    nums = [73, 74, 75, 71, 69, 72, 76, 73]

    print(dailyTemperatures(nums))
