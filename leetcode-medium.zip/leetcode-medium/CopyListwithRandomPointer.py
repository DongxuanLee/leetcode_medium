"""
# Definition for a Node.
class Node(object):
    def __init__(self, val, next, random):
        self.val = val
        self.next = next
        self.random = random
"""


class Solution(object):
    def copyRandomList(self, head):
        """
        :type head: Node
        :rtype: Node
        """

        p = head
        while p:
            pcopy = p
            p.next = pcopy
            p = pcopy.next
        newhead = head.next
        p = head
        q = newhead
        while q:
            q.random = p.random.next
            p = q.next
            q.next = p.next
            q = p.next
        return newhead

