# Definition for a binary tree node.
class TreeNode(object):
    def __init__(self, x):
        self.val = x
        self.left = None
        self.right = None

class Solution(object):
    def buildTree(self, preorder, inorder):
        """
        :type preorder: List[int]
        :type inorder: List[int]
        :rtype: TreeNode
        """
        if not preorder or not inorder:
            return
        pre = 0
        root = preorder[pre]
        rootNode = TreeNode(root)
        print(rootNode.val)
        if pre<len(preorder):
            if len(inorder)-1>0:
                for i in range(len(inorder)):
                    if inorder[i]==root:
                        leftNode = self.buildTree(preorder[pre+1:i+1],inorder[0:i])
                        rootNode.left = leftNode
                        # if leftNode:
                        #     print(leftNode.val)
                        # else:
                        #     print('no left')

                        rightNode = self.buildTree(preorder[i+1:],inorder[i+1:])
                        rootNode.right = rightNode
                        # if rightNode:
                        #     print(rightNode.val)
                        # else:
                        #     print('no right')
            else:
                return rootNode
        return rootNode


if __name__ == '__main__':
    preorder = [3, 9,4, 20, 15, 7]
    inorder = [4,9, 3, 15, 20, 7]
    so = Solution()
    print(so.buildTree(preorder, inorder))
